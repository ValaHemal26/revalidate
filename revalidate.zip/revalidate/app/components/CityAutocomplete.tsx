import React, { useState, useRef, useEffect } from "react";
import { api } from "../api/api";

interface CityAutocompleteProps {
  value: string;
  onChange: (val: string) => void;
  placeholder: string;
}

export default function CityAutocomplete({ value, onChange, placeholder }: CityAutocompleteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [filteredCities, setFilteredCities] = useState<string[]>([]);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    onChange(val);
    fetchSuggestions(val);
    setIsOpen(true);
  };

  const handleSelect = (city: string) => {
    onChange(city);
    setIsOpen(false);
  };

  return (
    <div ref={wrapperRef} style={{ position: "relative", width: "100%" }}>
      <input
        type="text"
        className="input-field"
        placeholder={placeholder}
        value={value}
        onChange={handleInputChange}
        onFocus={() => {
          setFilteredCities(value ? CITIES.filter(c => c.toLowerCase().includes(value.toLowerCase())) : CITIES);
          setIsOpen(true);
        }}
        required
      />
      {isOpen && filteredCities.length > 0 && (
        <ul style={{
          position: "absolute",
          top: "100%", left: 0, right: 0,
          background: "var(--bg-secondary)",
          border: "1px solid var(--border-color)",
          borderRadius: "var(--radius-sm)",
          boxShadow: "var(--shadow-md)",
          maxHeight: "200px",
          overflowY: "auto",
          zIndex: 1000,
          listStyle: "none",
          padding: "8px 0",
          marginTop: "4px"
        }}>
          {filteredCities.map((city, idx) => (
            <li
              key={idx}
              onClick={() => handleSelect(city)}
              style={{
                padding: "10px 16px",
                cursor: "pointer",
                color: "var(--text-primary)",
                transition: "background 0.2s"
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "var(--bg-tertiary)")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
            >
              {city}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
