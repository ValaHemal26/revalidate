import express from "express";
import { SearchCities, RequestCity, GetPendingLocations, ApproveLocation } from "../controller/location.controller.mjs";
import { verifyToken, requireRole } from "../middleware/auth.middleware.mjs";

export default function locationRoutes(router) {
  const locRouter = express.Router();

  // Public endpoint for autocomplete
  locRouter.get("/cities", SearchCities);

  // Operator endpoint to request new locations
  locRouter.post("/city", verifyToken, requireRole(["OPERATOR", "ADMIN"]), RequestCity);

  // Admin endpoints for review
  locRouter.get("/pending", verifyToken, requireRole(["ADMIN"]), GetPendingLocations);
  locRouter.post("/approve", verifyToken, requireRole(["ADMIN"]), ApproveLocation);

  router.use("/locations", locRouter);
}
